1 & 3.CREATE TABLE Customer (
    Id int NOT NULL,
    LastName nvarchar(40) ,
    FirstName nvarchar(40) not null,
	City nvarchar(40) ,
    Country nvarchar(40),
    Phone nvarchar(20) ,
	FaxNumber nvarchar(20);--updated col
 
    PRIMARY KEY (ID)
);

4. CREATE TABLE Orders(
    Id int NOT NULL,
    OrderDate datetime not null,
     OrderNumber nvarchar(10) ,
	TotalAmount decimal(12,2) ,
   CustomerId int FOREIGN KEY REFERENCES Customer(Id)
 
    PRIMARY KEY (Id)
);

CREATE TABLE Product(
    Id int NOT NULL,
   
     ProductnName nvarchar(50) ,
	UnitPrice decimal(12,2) ,
  Package nvarchar(30) ,
  IsDiscontinued bit,
 
    PRIMARY KEY (Id)
);


CREATE TABLE OrderItem(
    Id int NOT NULL,
   OrderId int FOREIGN KEY REFERENCES Orders(Id),
   ProductId int FOREIGN KEY REFERENCES Product(Id),
    
	UnitPrice decimal(12,2) ,
	Quantity int,
  
 
    PRIMARY KEY (Id)
);


2.
INSERT INTO [dbo].[Customer]
           ([Id]
           ,[LastName]
           ,[FirstName]
           ,[City]
           ,[Country]
           ,[Phone])
     VALUES
           (1
           ,'Reddy'
           ,'Smikesh'
           ,'Hyderabad'
           ,'India'
           ,'99999999999')
GO

7. select * from Customer where Firstname LIKE '__i%';
5. select * from Customer;--to display all customer details

INSERT INTO [dbo].[Customer]
           ([Id]
           
           ,[FirstName]
           
           ,[Country]
           ,[Phone])
     VALUES
           (2
           
           ,'Stuart'
           
           ,'Australia'
           ,'8888888888')
GO

6.select * from Customer where Country LIKE 'i%' or Country LIKE 'a%';--country starts with A or I

1.
INSERT INTO [dbo].[Customer]
           ([Id]
           ,[LastName]
           ,[FirstName]
           ,[City]
           ,[Country]
           ,[Phone])
     VALUES
           (3
           ,'Smith'
           ,'John'
           ,''
           ,'Germany'
           ,'9999988888')
GO
1. select * from Customer where Country='Germany';
2.select (FirstName+' '+ LastName ) as FullName from Customer;--cuatomer FullName

INSERT INTO [dbo].[Customer]
           ([Id]
           ,[LastName]
           ,[FirstName]
           ,[City]
           ,[Country]
		   ,[FaxNumber]
           ,[Phone])
     VALUES
           (4
           ,'Rao'
           ,'Anand'
           ,'Hyderabad'
           ,'India'
		   ,'555-123-4567'
           ,'9998888999'
		   )
3.select * from customer where FaxNumber is not null;--whose having fax number
4. select * from customer where FirstName LIKE '_U%';--customer name second letter starts with letter u

INSERT INTO [dbo].[Orders]
           ([Id]
           ,[OrderDate]
           ,[OrderNumber]
           ,[TotalAmount]
           ,[CustomerId])
     VALUES
           (1
           ,'2022-04-05 00:00:00'
           ,'abc'
           ,1000
           ,1)
.		   select *from Customer c left join Orders o on o.Customerid=c.id;--assignmening orders with customer
5. select *from Orders where TotalAmount >500 and TotalAmount<1500;--order details where total amount is greater than 500 md lessthan 1500
6. select *from Orders Order by OrderDate;--order details order by order date

INSERT INTO [dbo].[Orders]
           ([Id]
           ,[OrderDate]
           ,[OrderNumber]
           ,[TotalAmount]
           ,[CustomerId])
     VALUES
           (3
           ,'2022-02-05 00:00:00'
           ,'La D''abo' 
           ,800
           ,3)
GO

select *from Orders Order by OrderDate;
7.select * from Orders where OrderNumber='La D''abo' and OrderDate between '2022-02-05 00:00:00.000' and '2022-04-05 00:00:00.000';--order shipped by ship name between 2 dates
INSERT INTO [dbo].[Product]
           ([Id]
           ,[ProductnName]
           ,[UnitPrice]
           ,[Package]
           ,[IsDiscontinued])
     VALUES
           (1
           ,'Mobile'
           ,100
           ,'Accessories'
           ,0)
		   INSERT INTO [dbo].[Product]
           ([Id]
           ,[ProductnName]
           ,[UnitPrice]
           ,[Package]
           ,[IsDiscontinued])
     VALUES
           (2
           ,'Handwah'
           ,150
           ,'Exotic Liquids'
           ,0)
8.		   select * from Product where package='Exotic Liquids';--supplied by package name exotic liquids

INSERT INTO [dbo].[Product]
           ([Id]
           ,[ProductnName]
           ,[UnitPrice]
           ,[Package]
           ,[IsDiscontinued]
           ,[Pro_Same])
     VALUES
           (6
           ,'pc'
           ,30000
           ,''
           ,0
           ,'1')
9. 	--average of unit prices based on count of unit prices
  SELECT AVG(UnitPrice) as 'Average Price 1'FROM Product
  WHERE IsDiscontinued=0;
  
  OR
  
  SELECT AVG(UnitPrice) FROM  Product;
  
 10. --for printing shipping company(firstname) name and the ship names(lastname) if they are optional(having city as hyderabad)
  @ refered customer table
  
 select firstname,lastname from Customer where city='Hyderabad'
 
 11. --print all employees with manager name
 @ refer employee and depatment table
 
 SELECT E.EmpFirstName+' '+E.EmpLastName AS "Employee Name", 
   D.DepartmentName AS "Manager Name"
     FROM Employee E 
       JOIN Department D
         ON E.Departmentid = D.Departmenttid;
 12.--print all bill(unitPrice) including productname(productname), category name(package),price after discount(price after discount)
 --use product table
 --first add column price after discount column and then update column
 
 -UPDATE Product 
SET AfterDiscount = UnitPrice-50
(150
13.--print total price(unit price)  of orders(products) which have products supplied by 'Exotic Liquids' if the price is >50(150) and also print it by Company name(productname)

--select UnitPrice,ProductnName from Product Where 
(Package='exotic liquids' and UnitPrice>150)